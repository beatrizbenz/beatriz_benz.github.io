#include <stdio.h>
#include <math.h>

int main (){

    float salario,salario_familia;
    int n_dependentes;

    printf("Informe o salario do funcionario:\n ");
    scanf("%f",&salario);

    printf("Informe o numero de dependentes do funcionario:\n ");
    scanf("%d",&n_dependentes);

    salario_familia = salario + ((salario*0.02)*n_dependentes);

    printf("\n\n O sal�rio da familia do funcionario e: %2.f \n\n",salario_familia);


}
