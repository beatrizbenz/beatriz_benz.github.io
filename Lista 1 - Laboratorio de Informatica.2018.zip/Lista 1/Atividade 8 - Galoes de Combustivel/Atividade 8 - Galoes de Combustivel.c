#include <stdio.h>
#include <math.h>

int main(){

    float galao_utilizado,velocidade1,tempo1,distancia1,galao1 =0;

    printf("Informe o tempo em horas de viagem:");
    scanf("%f",&tempo1);

    printf("Informe a velocidade media: ");
    scanf("%f",&velocidade1);

    distancia1 = (velocidade1*tempo1);
    galao_utilizado = (distancia1/12)/5;


       while (galao_utilizado>galao1){
                galao1=galao1+1;
        }

    printf("\n");
    printf("Sabe que um automovel faz 12Km/l. \n");
    printf("E que a distancia percorrida e de %.2fkm \n",distancia1);
    printf("Visto que cada galao de gasolina possui 5 litros \n");
    printf("e o maximo de combustivel fornecido por galao serve ate 60km \n");
    printf("Podemos afirmar que precisara comprar %.0f galao/es de combustivel \n",galao1);
    printf("Pois sera necessario utilizar %.2f de galao/es \n",galao_utilizado);
    printf("\n\n");

}
