#include <stdio.h>
#include <math.h>

int main(){
    float x1,x2,y1,y2,distancia;

    printf("A seguir, devera ser informado dois pontos de um plano cartesiano \n");
    printf("Comecando pelo primeiro ponto P(X1,Y1)");
    printf("\n\nInforme o valor de X1:");
    scanf("%f",&x1);
    printf("Informe o valor de Y1:");
    scanf("%f",&y1);
    printf("\n\nAgora o segundo ponto Q(X2,Y2)\n\n");
    printf("Informe o valor de X2:");
    scanf("%f",&x2);
    printf("Informe o valor de Y2:");
    scanf("%f",&y2);

    distancia = sqrt (((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)));
    printf("\n \n A distancia entre os dois pontos informado e: %.2f \n\n\n",distancia);


}
