#include <stdio.h>
#include <math.h>


int main (){

    float salario_minimo,horas_trabalhadas,salario_trabalhado,salario_extra,horas_extras,salario_ausente,horas_ausentes,inss,salario_final;


    printf(" \n Informe o valor do salario minimo: ");
    scanf("%f",&salario_minimo);

    printf("\n Informe a quantidade de horas trabalhadas: ");
    scanf("%f",&horas_trabalhadas);
    salario_trabalhado <- horas_trabalhadas*(salario_minimo*0.04);

    printf("\n Informe a quantidade de horas extras: ");
    scanf("%f",&horas_extras);
    salario_extra = horas_extras*((salario_trabalhado/horas_trabalhadas)*1.50);

    printf("\n Informe a quantidade de horas ausentes: ");
    scanf("%f",&horas_ausentes);
    salario_ausente = horas_ausentes*(salario_minimo*0.04);

    inss = salario_minimo* 0.11;
    // Calculo
    salario_final = (((salario_extra+salario_trabalhado)-salario_ausente)-inss);

    printf("\n  ");
    printf("\n  ");
    printf("\n O valor do sal�rio a ser pago para o colaborador e de R$ %2.f \n\n",salario_final);


}
