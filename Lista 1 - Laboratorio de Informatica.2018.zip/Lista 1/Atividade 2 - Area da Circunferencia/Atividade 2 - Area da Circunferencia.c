#include <stdio.h>
#include <math.h>
#define PI 3.14159265;

int main(){
    float raio, area;

    printf("Digite o valor do raio da circunferencia: ");
    scanf("%f",&raio);

    area = (raio*raio)*PI

    printf("A area deste raio informado e: %2.f", area);

    return 0;

}
