#include <stdio.h>
#include <math.h>

int main(){

    float graus,fahrenheit;
    printf("Informe a temperatura em Graus Centigrados: ");
    scanf("%f",&graus);

    fahrenheit = (9*graus+160)/5;

    printf("\n\n\n");
    printf("A temperatura e %2.fF \n\n",fahrenheit);

}
