#include <stdio.h>
#include <math.h>

int main(){
    int alunos,alunos2;

    printf("Digite o numero de alunos: ");
    scanf("%d",&alunos);

    printf("O numero de grupos que podem ser formados e: %d \n",alunos/4);
    printf("Obtendo-se o valor inteiro a quantidade de alunos que sobra para montar um outro grupo e: %d \n\n\n", alunos%4);
}
