#include <stdio.h>
#include <math.h>

int main (){
    // Se��o de Declara��es das vari�veis
    float preco_montadora,ipi,imc,preco_venda,lucro;

    // Se��o de Comandos, procedimento, fun��es, operadores, etc...
    printf("Digite o valor do pre�o do carro na montadora:\n");
    scanf("%f",&preco_montadora);


    lucro = preco_montadora*0.15;
    ipi = preco_montadora*0.11;
    imc = preco_montadora*0.17;
    preco_venda = preco_montadora + lucro + ipi + imc;

    printf("O preco de venda do carro sera de R$%2.f \n",preco_venda );
    printf("\n");
    printf("Os valores dos impostos sao: \n\n");
    printf("IPI: R$%2.f \n",ipi);
    printf("ICM: R$%2.f \n ",imc);
    printf("\n\n O valor do lucro e: R$ %2.f \n\n\n",lucro);
}
