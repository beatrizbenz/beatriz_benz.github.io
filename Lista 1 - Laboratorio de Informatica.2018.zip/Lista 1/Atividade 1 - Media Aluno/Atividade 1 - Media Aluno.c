#include <stdio.h>

/*
Crie uma calculadora

*/
int main(){
    float nota1 = 0;
    float nota2 = 0;
    float nota3 = 0;
    float nota4 = 0;

    printf("Digite uma nota do aluno: \n");
    scanf("%f",&nota1);
    printf("Digite outra nota:\n");
    scanf("%f",&nota2);
    printf("Digite outra nota:\n");
    scanf("%f",&nota3);
    printf("Digite outra nota:\n");
    scanf("%f",&nota4);
    printf("\n");
    printf("\n");
    printf("\n");
    printf("A media do aluno e: %2.f\n",((nota1+nota2+nota3+nota4)/4));

    return 0;

}
