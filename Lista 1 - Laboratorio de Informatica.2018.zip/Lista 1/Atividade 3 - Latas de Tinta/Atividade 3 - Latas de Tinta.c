#include <stdio.h>
#include <math.h>


int main(){
    float valor_lata,raio,altura,area_cilindro,qtd_lata_utilizada,cont_litro,cont_lata,valor_a_pagar;
    float PI = 3.14159265;
    // Atribui��o dos contadores

    cont_litro= 0;
    cont_lata= 0;

    // Entrada de Valores
    printf("\n Digite o pre�o da lata de tinta: ");
    scanf("%f",&valor_lata);

    printf("\n Informar o raio da superficie do tanque cilindrico: ");
    scanf("%f",&raio);

    printf("\n Informar a altura do tanque cilindrico: ");
    scanf("%f",&altura);

    area_cilindro = (2*(PI*((raio)*((raio)+(altura)))));


    qtd_lata_utilizada = area_cilindro/15;

   while (area_cilindro/3 > cont_litro) {
       cont_litro = cont_litro+5;
       cont_lata = cont_lata+1;
   }


    // Saida de Valores
    printf("\n  ");
    printf("\n  ");
    printf("A altura do cilindro informado e: %.2f", altura);
    printf("\n O raio do cilindro informado e: %.2f", raio);
    printf("\n A area do cilindro calculado e: %.2f", area_cilindro);
    printf("\n  ");
    printf("\n  ");
    printf("\n Sabe-se que uma lata de tinta pinta 15m2.");
    printf("\n Ent�o podemos concluir que, para pintar %.2f m2",area_cilindro);
    printf("\n  ");
    printf("\n Sera necessario..\n  ");
    printf("\n Quantidade de Lata Utilizada: %f", qtd_lata_utilizada);
    printf("\n Quantidade de Lata Necessario Comprar: %.2f", cont_lata);
    valor_a_pagar = (cont_lata*valor_lata);
    printf("\n Valor a pagar R$%.2f",valor_a_pagar);
    printf("\n\n\n  ");
    return 0;
}
